import os
import zipfile
import pandas as pd
from tqdm import tqdm

# --- 1. UNZIP ---
def unzip_data(zip_path, extract_to):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    print(f"[✓] Extracted to {extract_to}")

# --- 2. EVENT MAPPER ---
def map_event_to_code(event):
    mapping = {
        "JumpStart": 1,
        "JumpEnd": 2,
        "RightMoveStart": 3,
        "RightMoveEnd": 4,
        "LeftMoveStart": 5,
        "LeftMoveEnd": 6,
        "StompKillGoomba": 7,
        "StompKillGreenKoopa": 8,
        "ShellKillGoomba": 9,
        "FireKillGoomba": 10,
        "FireKillGreenKoopa": 11,
        "BlockPowerDestroy": 12,
        "BlockCoinDestroy": 13,
        "CollectCoin": 14,
        "CollectCoinBulletBill": 15,
        "DeathByGap": 99,
        "DieByGoomba": 98,
        "DieByGreenKoopa": 97,
        "LostLevel": 96,
        "WonLevel": 95,
    }
    return mapping.get(event, 0)

# --- 3. PROCESS A SINGLE FILE ---
def process_csv(file_path, participant_id, filename):
    df = pd.read_csv(file_path)
    jumps = right = left = kills = powerups = coins = deaths = 0
    trajectory = []

    for _, row in df.iterrows():
        event = row['Event']
        code = map_event_to_code(event)

        if event == 'JumpStart':
            jumps += 1
        elif event == 'RightMoveStart':
            right += 1
        elif event == 'LeftMoveStart':
            left += 1
        elif 'Kill' in event:
            kills += 1
        elif 'BlockPowerDestroy' in event:
            powerups += 1
        elif 'Coin' in event or 'CollectCoin' in event:
            coins += 1
        elif 'Death' in event or event.startswith('Die'):
            deaths += 1

        trajectory.append([
            participant_id,
            filename,
            jumps,
            right,
            left,
            kills,
            powerups,
            coins,
            deaths,
            code
        ])

    return trajectory

# --- 4. MAIN PROCESSING ---
def process_all_to_single_csv(input_root, output_csv_path):
    all_trajectories = []

    for dirpath, _, filenames in os.walk(input_root):
        for fname in filenames:
            if fname.endswith(".csv"):
                full_path = os.path.join(dirpath, fname)
                relative_path = os.path.relpath(full_path, input_root)

                participant_id = os.path.basename(os.path.dirname(full_path))
                trajectory = process_csv(full_path, participant_id, fname)
                all_trajectories.extend(trajectory)

    df = pd.DataFrame(all_trajectories, columns=[
        'participant_id', 'filename', 'jumps', 'right_moves', 'left_moves',
        'kills', 'powerups', 'coins_collected', 'deaths', 'event_code'
    ])
    df.to_csv(output_csv_path, index=False)
    print(f"[✓] Combined CSV saved to: {output_csv_path}")

# --- 5. RUN ---
if __name__ == "__main__":
    zip_file = "AnonymizedDirectory.zip"
    extracted_folder = "AnonymizedDirectory"
    output_combined_csv = "combined_trajectories.csv"

    if not os.path.exists(extracted_folder):
        unzip_data(zip_file, extracted_folder)

    print("[✓] Generating single combined trajectory file...")
    process_all_to_single_csv(extracted_folder, output_combined_csv)
    print("[✓] Done.")
